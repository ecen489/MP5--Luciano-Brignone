package com.example.quizzapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list;
    int score;
    int corr;
    Button reset;
    TextView points;
    int REQ_CODE = 1234; // anything I want

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = (ListView)findViewById(R.id.listview);
        reset= (Button) findViewById(R.id.reset);
        points = (TextView) findViewById(R.id.score);

        points.setText("SCORE " + score);

        final Intent intent = new Intent(this, questions.class);

        ArrayList<String> arraylist = new ArrayList<>();

        // different topics stored in arraylist
        arraylist.add("Soccer");
        arraylist.add("Science");
        arraylist.add("Fun Questions");

        ArrayAdapter<String> adapt = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arraylist);
        list.setAdapter(adapt);

        // list clicker to go to new activity
        list.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> list, View row, int index, long id) {
                        String subject = list.getItemAtPosition(index).toString();
                        intent.putExtra("subject", subject);
                        startActivityForResult(intent, REQ_CODE);
                    }
                }
        );
        // reset button
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                score = 0;
                corr = 0;
                points.setText("SCORE "+ score);
            }
        });
    } // the return

    protected void onActivityResult(int requestCode, int resultCode, Intent intent){
        if (requestCode == REQ_CODE){
            String ans = intent.getStringExtra("answer");
            try {
                corr = Integer.parseInt(ans);
                score = corr + score;
            } catch (Exception e){
                e.printStackTrace();
            }
            points.setText("SCORE " + score);
        }
    }
}
