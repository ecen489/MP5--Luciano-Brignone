package com.example.quizzapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.view.View;
import android.content.Intent;
import java.util.Random;

public class questions extends AppCompatActivity {

    Button done;
    TextView question;
    EditText answer;
    String q1 = "Soccer";
    String q2 = "Science";
    String q3 = "Fun Questions";
    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        question = (TextView) findViewById(R.id.display);
        answer = (EditText) findViewById(R.id.editText);
        done = (Button) findViewById(R.id.button);

        Intent intent = getIntent();
        final String head = intent.getStringExtra("subject");
        Random rand = new Random();

        // questions
        if(head.equals(q1)){
            //Random rand = new Random();
            num = (rand.nextInt(4));
            if(num == 0){
                question.setText("who is the best player (last name)?");
            }
            if(num == 1){
                question.setText("which country has won the most World cups?");
            }
            if(num == 2){
                question.setText("who won the previous World Cup?");
            }
            if(num == 3){
                question.setText("where is Diego Maradona from?");
            }
            else{
                question.setText("who is on top of the La liga Table?");
            }
        }
        if(head.equals(q2)){
            //Random rand = new Random();
            num = rand.nextInt(4);
            if(num == 0){
                question.setText("how long does it take light from sun to reach us(type minutes)?");
            }
            if(num == 1){
                question.setText("Which planet has the most moons?");
        }
            if(num == 2){
                question.setText("An octopus can fit through any hole larger than its what?");
            }
            if(num ==3){
                question.setText("what is a group of whales called?");
            }
            else{
                question.setText("Whats the 1st planet discovered using telescope?");
            }
        }
        if(head.equals(q3)){
            //Random rand = new Random();
            num = rand.nextInt(4);
            if(num == 0){
                question.setText("...... have fewer toes on their back paws");
            }
            if(num == 1){
                question.setText("Scotland has 421 words for......?");
            }
            if(num == 2){
                question.setText("A cow-bison hybrid is called a ....?");
            }
            if(num == 3){
                question.setText("what letter doesn't appear in any state name?");
            }
            else {
                question.setText("whats the answer to life?");
            }
        }
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent = new Intent();
                String typed = answer.getText().toString();

                // answers and sending intent back with proper score
                if (typed.equalsIgnoreCase("Messi") && head.equalsIgnoreCase("Soccer")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("Brazil") && head.equalsIgnoreCase("Soccer")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("France") && head.equalsIgnoreCase("Soccer")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("Argentina") && head.equalsIgnoreCase("Soccer")) {
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("Barcelona") && head.equalsIgnoreCase("Soccer")) {
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("eight") && head.equalsIgnoreCase("Science")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("jupiter") && head.equalsIgnoreCase("Science")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("beak") && head.equalsIgnoreCase("Science")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("pod") && head.equalsIgnoreCase("Science")) {
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("Uranus") && head.equalsIgnoreCase("Science")) {
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("cats") && head.equalsIgnoreCase("Fun Questions")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("snow") && head.equalsIgnoreCase("Fun Questions")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("beefalo") && head.equalsIgnoreCase("Fun Questions")){
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("q") && head.equalsIgnoreCase("Fun Questions")) {
                    backIntent.putExtra("answer", "1");

                }
                else if (typed.equalsIgnoreCase("forty two") && head.equalsIgnoreCase("Fun Questions")) {
                    backIntent.putExtra("answer", "1");
                }
                else {
                    backIntent.putExtra("answer", "0");
                }
                setResult(RESULT_OK, backIntent);
                finish();
            }
        });
    }
}
